# Recommender Systems for Insurance Marketing
## Replicative Study by Luke Strassburg
## CSCI 5123 Spring 2025

This zip drive contains all the code I used for my project. Specifically my personal implementations of all the various models used throughout the study.

- ARules.Rmd: Association Rules code. Made from scratch. Uses ARules library in R.
- features.csv: Feature indicator dataset. Made myself using cues from the given code for the ML models. Could be slightly off compared to what was actually used in the published paper.
- IBCF.Rmd: My personal implementation of IBCF using Recommenderlab library in R. Made from scratch.
- implement_als.py: My implementation of ALS using the implicit package in python. Made from scratch.
- jacaard_df.csv: Jacaard similarity matrix between all the items in the dataset
- MF.Rmd: All my code for the matrix factorization techniques (LibFM, GLRM, and SLIM). Made all of these from scratch attempting to mirror the ML pipelines from the provided code.
- Replication.ipynb: My main workspace that walks through all the code and thought process for all of the models. Contains actual code for the Logistic GLMS and ML Models (Category Boost, Deep Learning, LightGBM, and XGboost). The ML models code was provided and was adapted to fit with the current implementations of the packages they use. Logistic GLMs code was created by me.